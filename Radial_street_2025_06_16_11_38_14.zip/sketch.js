let heroi;
let inimigos = [];
let itens = [];
let pontuacao = 0;
let gameOver = false;

const LARGURA_TELA = 800;
const ALTURA_TELA = 600;
const TAMANHO_HEROI = 30;
const VELOCIDADE_HEROI = 5;
const TAMANHO_INIMIGO = 25;
const TAMANHO_ITEM = 15;
const NUM_INIMIGOS = 5;
const NUM_ITENS = 3;

function setup() {
    createCanvas(LARGURA_TELA, ALTURA_TELA);
    resetGame();
}

function resetGame() {
    heroi = {
        x: LARGURA_TELA / 2,
        y: ALTURA_TELA - 50,
        cor: color(0, 200, 255) // Azul claro
    };
    inimigos = [];
    itens = [];
    pontuacao = 0;
    gameOver = false;

    // Gerar inimigos
    for (let i = 0; i < NUM_INIMIGOS; i++) {
        inimigos.push({
            x: random(TAMANHO_INIMIGO / 2, LARGURA_TELA - TAMANHO_INIMIGO / 2),
            y: random(-ALTURA_TELA, 0), // Começam acima da tela
            velocidade: random(1, 4),
            cor: color(255, 50, 50) // Vermelho
        });
    }

    // Gerar itens
    for (let i = 0; i < NUM_ITENS; i++) {
        itens.push({
            x: random(TAMANHO_ITEM / 2, LARGURA_TELA - TAMANHO_ITEM / 2),
            y: random(-ALTURA_TELA * 2, -ALTURA_TELA), // Começam bem acima
            cor: color(50, 255, 50) // Verde
        });
    }
}

function draw() {
    background(40); // Fundo escuro

    if (!gameOver) {
        // Mover herói
        moverHeroi();
        desenharHeroi();

        // Atualizar e desenhar inimigos
        for (let i = inimigos.length - 1; i >= 0; i--) {
            let inimigo = inimigos[i];
            inimigo.y += inimigo.velocidade;
            desenharInimigo(inimigo);

            // Se o inimigo sair da tela, reposicionar
            if (inimigo.y > ALTURA_TELA + TAMANHO_INIMIGO / 2) {
                inimigo.y = random(-ALTURA_TELA, 0);
                inimigo.x = random(TAMANHO_INIMIGO / 2, LARGURA_TELA - TAMANHO_INIMIGO / 2);
                inimigo.velocidade = random(1, 4); // Nova velocidade
            }

            // Colisão com inimigo
            if (detectarColisao(heroi, TAMANHO_HEROI, inimigo, TAMANHO_INIMIGO)) {
                gameOver = true;
            }
        }

        // Atualizar e desenhar itens
        for (let i = itens.length - 1; i >= 0; i--) {
            let item = itens[i];
            item.y += 2; // Velocidade dos itens
            desenharItem(item);

            // Se o item sair da tela, reposicionar
            if (item.y > ALTURA_TELA + TAMANHO_ITEM / 2) {
                item.y = random(-ALTURA_TELA * 2, -ALTURA_TELA);
                item.x = random(TAMANHO_ITEM / 2, LARGURA_TELA - TAMANHO_ITEM / 2);
            }

            // Colisão com item
            if (detectarColisao(heroi, TAMANHO_HEROI, item, TAMANHO_ITEM)) {
                pontuacao += 10;
                itens.splice(i, 1); // Remover item coletado

                // Gerar novo item
                itens.push({
                    x: random(TAMANHO_ITEM / 2, LARGURA_TELA - TAMANHO_ITEM / 2),
                    y: random(-ALTURA_TELA * 2, -ALTURA_TELA),
                    cor: color(50, 255, 50)
                });
            }
        }

        // Exibir pontuação
        fill(255);
        textSize(20);
        text("Pontuação: " + pontuacao, 10, 30);

    } else {
        // Tela de Game Over
        fill(255);
        textSize(50);
        textAlign(CENTER, CENTER);
        text("GAME OVER", LARGURA_TELA / 2, ALTURA_TELA / 2 - 40);
        textSize(25);
        text("Pontuação Final: " + pontuacao, LARGURA_TELA / 2, ALTURA_TELA / 2);
        textSize(20);
        text("Pressione 'R' para reiniciar", LARGURA_TELA / 2, ALTURA_TELA / 2 + 50);
    }
}

function moverHeroi() {
    if (keyIsDown(LEFT_ARROW)) {
        heroi.x -= VELOCIDADE_HEROI;
    }
    if (keyIsDown(RIGHT_ARROW)) {
        heroi.x += VELOCIDADE_HEROI;
    }
    if (keyIsDown(UP_ARROW)) {
        heroi.y -= VELOCIDADE_HEROI;
    }
    if (keyIsDown(DOWN_ARROW)) {
        heroi.y += VELOCIDADE_HEROI;
    }

    // Limitar movimento do herói à tela
    heroi.x = constrain(heroi.x, TAMANHO_HEROI / 2, LARGURA_TELA - TAMANHO_HEROI / 2);
    heroi.y = constrain(heroi.y, TAMANHO_HEROI / 2, ALTURA_TELA - TAMANHO_HEROI / 2);
}

function desenharHeroi() {
    fill(heroi.cor);
    rectMode(CENTER);
    rect(heroi.x, heroi.y, TAMANHO_HEROI, TAMANHO_HEROI);
}

function desenharInimigo(inimigo) {
    fill(inimigo.cor);
    rectMode(CENTER);
    rect(inimigo.x, inimigo.y, TAMANHO_INIMIGO, TAMANHO_INIMIGO);
}

function desenharItem(item) {
    fill(item.cor);
    ellipse(item.x, item.y, TAMANHO_ITEM, TAMANHO_ITEM);
}

function detectarColisao(obj1, tamanho1, obj2, tamanho2) {
    let distancia = dist(obj1.x, obj1.y, obj2.x, obj2.y);
    // Colisão simples baseada na distância entre os centros e os raios/metade dos lados
    // Considerando que os objetos são quadrados ou círculos de tamanho similar
    return distancia < (tamanho1 / 2 + tamanho2 / 2);
}

function keyPressed() {
    if (gameOver && key === 'r' || key === 'R') {
        resetGame();
    }
}